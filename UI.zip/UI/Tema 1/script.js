document.write('<p id="pp1">I love coding.</p>'); 
    document.write('<p id="pp2">I have dog.</p>'); 
    document.write('<p id="pp3">My car is fast.</p>'); 
    document.write('<p id="pp4">I love programming. </p>'); 
    document.write('<p id="pp5">Everiday I get up at 7AM..</p>');     
function Function1()
{
    document.getElementById("h1").innerHTML=document.getElementById("pp1").textContent;
    document.getElementById("h2").innerHTML=document.getElementById("pp2").textContent;
    document.getElementById("h3").innerHTML=document.getElementById("pp3").textContent;
    document.getElementById("h4").innerHTML=document.getElementById("pp4").textContent;
    document.getElementById("h5").innerHTML=document.getElementById("pp5").textContent;
}
function Color()
{
    document.getElementById('h1').style = 'color: blue';
    document.getElementById('h2').style = 'color: blue';
    document.getElementById('h3').style = 'color: blue';
    document.getElementById('h4').style = 'color: red';
    document.getElementById('h5').style = 'color: red';
}