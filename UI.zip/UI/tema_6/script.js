let list =document.getElementById('list');
let dataArr = [];

function getProductName(){
    return document.getElementById('product-input').value;
}

function displayProduct(){
    let productName = getProductName();
    //Create list element
    let createProduct = document.createElement('li');
    createProduct.textContent = productName;
    //Create input field for quantity
    let createQuantity = document.createElement('input');
    createQuantity.setAttribute('type', 'number');
    createQuantity.setAttribute('placeholder', 'Quantity');
    //Create input field for unit
    let createUnit = document.createElement('input');
    createUnit.setAttribute('type', 'text');
    createUnit.setAttribute('placeholder', 'Unit');
    //Attach created ellements in their parent nodes
    list.appendChild(createProduct);
    list.lastElementChild.appendChild(createQuantity);
    list.lastElementChild.appendChild(createUnit);
    

}

function getProductData(){
    for(let i = 0;i < list.childNodes.length - 1; i++ ){
        console.log(list.childNodes[i]);
        let data = {
            name: list.childNodes[i]
            
        }
        dataArr.push(data);
        
    }
    return dataArr;
}


document.getElementById('product-button').addEventListener('click', displayProduct);
document.getElementById('post-button').addEventListener('click', getProductData);
